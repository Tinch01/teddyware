from django.urls import path
from .views import *
from .views import registrar_usuario

urlpatterns = [ 
    

    # path('', vista_registro.as_view(), name="Autenticacion"), # lo que tenia, ya no mas.
    path('registrar_usuario',registrar_usuario, name="Registrar_usuario"),
    path('cerrar_sesion',cerrar_sesion, name="cerrar_sesion"),
    path('logear',logear, name="logear"),
    path('mi_perfil',view_mi_perfil, name='Mi_perfil'),
    path('editar_eliminar_usuario', editar_eliminar_usuario, name="editar_eliminar_usuario"),
    path('editar_eliminar_usuario/<str:id>/', editar_eliminar_usuario, name='editar_eliminar_usuario'),
    path('editar_perfil',editar_perfil, name='editar_perfil'),
    path('editar_perfil/<str:id>/', editar_perfil, name='editar_perfil'),
    path('eliminar_usuario/<str:id>/', eliminar_usuario, name='eliminar_usuario'),
]