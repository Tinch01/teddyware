from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
import re

class RegistroUsuarioForm(UserCreationForm):
    correo = forms.EmailField(required=True)
    nombre = forms.CharField(max_length=30)
    apellido = forms.CharField(max_length=30)

    class Meta:
        model = User
        # fields = ['correo', 'nombre', 'apellido', 'username', 'password1', 'password2']
        fields = ['correo', 'nombre', 'apellido', 'password1', 'password2']



class EditarPerfilForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name',]

    def clean_username(self):
        username = self.cleaned_data.get('username')

        # Verificar si es una dirección de correo electrónico válida
        try:
            validate_email(username)
        except ValidationError:
            raise ValidationError("El nombre de usuario debe ser una dirección de correo electrónico válida.")

        return username
    
    def clean_first_name(self):
        first_name = self.cleaned_data.get('first_name')

        # Verificar si el campo está vacío
        if not first_name:
            raise ValidationError("El campo 'Nombre' no puede estar vacío.")

        return first_name
    
    def clean_last_name(self):
        last_name = self.cleaned_data.get('last_name')

        # Verificar si el campo está vacío
        if not last_name:
            raise ValidationError("El campo 'Apellido' no puede estar vacío.")

        return last_name