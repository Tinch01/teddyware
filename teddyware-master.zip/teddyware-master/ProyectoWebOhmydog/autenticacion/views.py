from django.shortcuts import render, redirect
# from django.views.generic import View
# from django.contrib.auth.forms import UserCreationForm, 
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserChangeForm
from .forms import *
from django.shortcuts import get_object_or_404, redirect, render




def registrar_usuario(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            correo = form.cleaned_data['correo']
            username = form.cleaned_data['correo']  #sobreescibiendo siemppre username por lo que entró como correo
            password = form.cleaned_data['password1']
            nombre = form.cleaned_data['nombre']
            apellido = form.cleaned_data['apellido']

            #INICIO CHECK DE "USERNAME" para evitar repetidos, hecho por martinds "a mano"
            print('=================')
            for usu in User.objects.all():
                print(usu)
                print(f"tiene username: {usu.username}")
                print(f"tiene correo: {usu.email}")
                print('')
            print('=================')
            if User.objects.filter(username=username).exists(): #si entra aca es porque ya existia un usuario con el campo "username" que coincide con el mail que se ingresó
                print("Correo electronico ingresado ya estaba registrado.")
                error_message = "Correo electronico ya en uso."
                return render(request, r"registro/registro.html", {'form': form, 'error_message': error_message})
            #FIN CHECK DE "USERNAME"para evitar repetidos, hecho por martinds "a mano" 
            

            if password == username or password == nombre or  password == apellido or  password == correo:
                print("La contraseña coincide con alguno de los datos personales.")
                error_message = "La contraseña coincide con alguno de los datos personales."
                return render(request, r"registro/registro.html", {'form': form, 'error_message': error_message})
            elif username in password or nombre in password or apellido in password or correo in password:
                print("La contraseña contiene alguno de los datos personales.")
                error_message = "La contraseña contiene alguno de los datos personales."
                return render(request, r"registro/registro.html", {'form': form, 'error_message': error_message})
            elif len(password) < 8:
                print("La contraseña debe contener al menos 8 caracteres.")
                error_message = "La contraseña debe contener al menos 8 caracteres."
                return render(request, r"registro/registro.html", {'form': form, 'error_message': error_message})
            elif password.isdigit():
                print("La contraseña no puede estar formada completamente por numeros.")
                error_message = "La contraseña no puede estar formada completamente por numeros."
                return render(request, r"registro/registro.html", {'form': form, 'error_message': error_message})
            else:
                # Crear el usuario y asignar los valores a los campos correspondientes
                user = User.objects.create_user(username=username, email=correo, password=password) #sobreescibiendo siemppre username por lo que entró como correo
                user.first_name = nombre
                user.last_name = apellido
                user.save()
                messages.success(request, 'El usuario se creó con éxito.')
                print(f"Se registro el usuario: {user}")
                print(f"{user.username}")
                print(f"{user.email}")
                print(f"{user.first_name}")
                print(f"{user.last_name}")

                # Opcional: Puedes realizar alguna acción adicional después de registrar al usuario
                #en este caso pasar al formulario de registro de perro.
                return redirect('Registrar_perro')

    else:
        form = RegistroUsuarioForm()
    return render(request, r"registro/registro.html",{"form":form})


def cerrar_sesion(request):
    logout(request)
    return redirect('Home')


#cambia el label de "username" para pedir "correo electronico", si falla algo usar el loguear de abajo que esta comentado.
def logear(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            nombre_usuario = form.cleaned_data.get("username")
            contra = form.cleaned_data.get("password")
            usuario = authenticate(username=nombre_usuario, password=contra)
            if usuario is not None:
                login(request, usuario)
                return redirect('Home')
            else:
                messages.error(request, "Autenticación incorrecta.")
        else:
            messages.error(request, "Autenticación fallida o se ingresaron datos incorrectos.")
    else:
        form = AuthenticationForm()
        form.fields['username'].label = 'Correo electrónico'

    return render(request, "login/login.html", {"form": form})



def view_mi_perfil(request):
    return render(request, r'autenticacion/mi_perfil.html')

def editar_eliminar_usuario(request):
    usuarios= User.objects.all()
    mail_usuario_actual = request.user.email
    usuarios = [usuario for usuario in usuarios if usuario.email != mail_usuario_actual]
    return render(request, r'edicion/editar_eliminar_usuario.html', {'usuarios': usuarios})


def editar_perfil(request, id):
    usuario = User.objects.get(id=id)

    if request.method == 'POST':
        formulario = EditarPerfilForm(request.POST, instance=usuario)

        if formulario.is_valid():
            formulario.save()
            return redirect('editar_eliminar_usuario')  # Reemplaza 'mis_perros' con la ruta a la página que muestra los perros del usuario

    else:
        formulario = EditarPerfilForm(instance=usuario)

    return render(request, 'edicion/editar_perfil.html', {'formulario': formulario})

def eliminar_usuario(request, id):
    usuario = get_object_or_404(User, id=id)
    
    if request.method == 'POST':
        if 'confirmar' in request.POST:
            usuario.delete()
        return redirect('editar_eliminar_usuario')
    
    context = {
        'usuario': usuario
    }
    
    return render(request, 'edicion/eliminar_usuario.html', context)

#ANDA PERFECTO:
# def logear(request):
#     if request.method=="POST":
#         form=AuthenticationForm(request, data=request.POST)
#         if form.is_valid():
#             nombre_usuario=form.cleaned_data.get("username")
#             contra=form.cleaned_data.get("password")
#             usuario=authenticate(username=nombre_usuario, password=contra)
#             if usuario is not None:
#                 login(request, usuario)
#                 return redirect('Home')
#             else:
#                 messages.error(request, "Autenticacion incorrecta.")
#         else:
#             messages.error(request, "Autenticacion fallida o se ingresaron datos incorrectos.")
#     form=AuthenticationForm()

#     return render(request, r"login/login.html",{"form":form})
        