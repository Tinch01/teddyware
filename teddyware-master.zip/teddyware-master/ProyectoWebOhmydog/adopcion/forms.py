from django import forms
from .models import Adopcion

class AdopcionForm(forms.ModelForm):
    nombre = forms.CharField(required=False, label="Nombre del perro (Solo si lo conoce)")
    raza = forms.CharField(required=False, label="Raza(Solo si tiene)")
    
    class Meta:
        model = Adopcion        
        exclude = ['adoptado','email_autor'] #INCLUIRÁ TODOS LOS CAMPOS DEL MODELO ADOPCION, EXCEPTO LOS DEL EXCLUDE
   
#    si no se ingresa nombre se guarda el valor por defecto:
    def clean_nombre(self):
        valor_predeterminado = 'Perro sin nombre'
        campo_vacio = self.cleaned_data['nombre']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
        
#    si no se ingresa raza se guarda el valor por defecto:
    def clean_raza(self):
        valor_predeterminado = 'Sin Raza'
        campo_vacio = self.cleaned_data['raza']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado


class EditarAdopcionForm(forms.ModelForm):
    
    nombre = forms.CharField(required=False, label="Nombre del perro (Solo si lo conoce)")
    raza = forms.CharField(required=False, label="Raza(Solo si tiene)")


    class Meta:
        model = Adopcion
        fields = ['nombre','edad','raza','descripcion','adoptado','genero']
        exclude = ['email_autor'] #INCLUIRÁ TODOS LOS CAMPOS DEL MODELO ADOPCION, EXCEPTO LOS DEL EXCLUDE
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 9}),
        }
        
#    si no se ingresa nombre se guarda el valor por defecto:
    def clean_nombre(self):
        valor_predeterminado = 'Perro sin nombre'
        campo_vacio = self.cleaned_data['nombre']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
    
#    si no se ingresa raza se guarda el valor por defecto:
    def clean_raza(self):
        valor_predeterminado = 'Sin Raza'
        campo_vacio = self.cleaned_data['raza']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
