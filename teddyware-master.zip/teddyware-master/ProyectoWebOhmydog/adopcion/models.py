from django.db import models

# Create your models here.
class Adopcion(models.Model):

    TAMANIOS_DISPONIBLES=[
        ('pequenio','pequenio'),
        ('mediano','mediano'),
        ('grande','grande'),
    ]
    GENEROS_DISPONIBLES = [
        ('macho', 'Macho'),
        ('hembra', 'Hembra'),
    ]

    id=models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=16, blank=True, null=True, default="Perro sin nombre")
    edad=models.PositiveIntegerField(max_length=2, blank=False, null=False)
    raza=models.CharField(max_length=50, blank=True, null=True, default="Sin raza")
    descripcion = models.CharField(max_length=240) #interesante saber que si desde el panel de admin le queremos cargar algo que supere la maxima longitud de caracteres, automaticamente lo recorta.
    adoptado = models.BooleanField(auto_created=False, default=False)
    genero = models.CharField(max_length=20, choices=GENEROS_DISPONIBLES, null=False, blank=False)
    tamanio = models.CharField(max_length=20, choices=TAMANIOS_DISPONIBLES, null=False,blank=False)
    email_autor= models.EmailField(null=False,blank=False)

    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now_add=True)


    class Meta:
        verbose_name='Adopcion'
        verbose_name_plural='Adopciones'

    def __str__(self):
        if(self.adoptado):
            auxStringEstado="Ya adoptado"
        else:
            auxStringEstado="En adopcion"
        #la variable auxStringEstado solo es usada para no imprimir "true/false", sino algo mas explicito.
        return f"Nombre: {self.nombre}, estado: {auxStringEstado}, descripcion: {self.descripcion}"
    
    def isAdoptado(self):
        return self.adoptado