from django.shortcuts import render,redirect,get_object_or_404
from adopcion.models import Adopcion
from .forms import EditarAdopcionForm,AdopcionForm
from django.contrib import messages
from django.db.models import Q
# Create your views here.


def listar_adopciones(request):
    if request.user.is_authenticated:            #si esta logueado se muestran asi...
        adopciones_mias = Adopcion.objects.filter(email_autor=request.user.email)
        adopciones_ajenas = Adopcion.objects.filter(~Q(email_autor=request.user.email))
        adopciones = adopciones_mias | adopciones_ajenas
        print("seran listadas:")
        print(adopciones)
    else:           #si no esta logueado se muestran asi...
        adopciones_mias = {}
        adopciones_ajenas = Adopcion.objects.all()
        print("seran listadas:")
        print(adopciones_ajenas)
    return render(request, r'adopcion\adopciones.html', {'adopciones_mias': adopciones_mias, 'adopciones_ajenas': adopciones_ajenas})


def ver_perro_adopcion(request, id):
    adopcion= Adopcion.objects.get(id=id)
    
    puedoEditar = False
    if request.user.is_authenticated:
        #podra editar solo si es su publicacion o si es administrador.
        puedoEditar = ((adopcion.email_autor == request.user.email) | request.user.is_superuser )
    print(f"perro {adopcion.nombre} es del usuario: {adopcion.email_autor}")
    return render(request, 'adopcion/ver_perro_adopcion.html', {'adopcion': adopcion, 'puedoEditar':puedoEditar})


def crear_adopcion(request):
    
    if request.method == 'POST':
        form = AdopcionForm(request.POST)
        if form.is_valid():
            adopGuardar=form.save(commit=False)
            adopGuardar.email_autor=request.user.email
            adopGuardar.save()
            return redirect('Adopcion')
        else:
            messages.error(request, 'Error en los datos ingresados.')
    else:
        form = AdopcionForm()

    return render(request, r'adopcion/form_crear_adopcion.html', {'form': form})





def editar_adopcion(request,id):
    adopcion = get_object_or_404(Adopcion, id=id)

    if request.method == 'POST':
        form = EditarAdopcionForm(request.POST, instance=adopcion)
        if form.is_valid():
            adopGuardar=form.save(commit=False)
            adopGuardar.email_autor=request.user.email
            adopGuardar.save()
            return redirect('Adopcion')
        else:
            messages.error(request, 'Error en los datos ingresados.')
    else:
        form = EditarAdopcionForm(instance=adopcion)

    return render(request, r'adopcion/editar_adopcion.html', {'adopcion':adopcion, 'form':form})


def eliminar_adopcion(request,id):
    adopcion = get_object_or_404(Adopcion, id=id)

    if request.method == 'POST':
        if 'confirmar' in request.POST:
            adopcion.delete()
        return redirect('Adopcion')
    
    return render(request, r'adopcion/eliminar_adopcion.html', {'adopcion':adopcion})



def marcar_adoptado(request,id):
    adopcion =get_object_or_404(Adopcion,id=id)
    if adopcion :
        adopcion.adoptado=True
        adopcion .save()
        print("PERRO ADOPTADO!")
    return redirect('Adopcion')  