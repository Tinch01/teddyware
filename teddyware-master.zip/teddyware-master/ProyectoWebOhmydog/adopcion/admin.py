from django.contrib import admin
from .models import Adopcion

# Register your models here.

class AdopcionAdmin(admin.ModelAdmin):
    readonly_fields=('created', 'updated')

#ESTA BIEN PARA PODER REGISTRAR ADOPCIONES.
admin.site.register(Adopcion, AdopcionAdmin)


