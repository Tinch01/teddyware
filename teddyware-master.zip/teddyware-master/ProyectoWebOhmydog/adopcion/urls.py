from django.urls import path
from django.conf import settings
from . import views

urlpatterns = [
    path('',views.listar_adopciones,name='Adopcion'),
    path('ver_perro_adopcion/', views.ver_perro_adopcion, name='ver_perro_adopcion'),
    path('ver_perro_adopcion/<str:id>/', views.ver_perro_adopcion, name='ver_perro_adopcion'),
#tener en cuenta que es el name es el referenciable desde el html, como por ej: desde el nav.

    path('crear_adopcion/', views.crear_adopcion, name='Crear_adopcion'),
    
    path('editar_perro_adopcion/<str:id>/', views.editar_adopcion, name='editar_perro_adopcion'),
    path('eliminar_perro_adopcion/<str:id>/', views.eliminar_adopcion, name='eliminar_perro_adopcion'),

    path('perro_adoptado/<str:id>/', views.marcar_adoptado, name='perro_adoptado'),



]
