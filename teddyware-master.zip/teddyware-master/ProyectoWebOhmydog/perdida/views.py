from django.shortcuts import render,redirect,get_object_or_404
from .models import Perdida
from django.contrib import messages
from .forms import PerdidaForm,EditarPerdidaForm
from django.db.models import Q

# Create your views here. 

def listar_perdidas(request):
    if request.user.is_authenticated:  
        perdidas_mias = Perdida.objects.filter(email_autor=request.user.email)
        perdidas_ajenas = Perdida.objects.filter(~Q(email_autor=request.user.email))
    else:
        perdidas_mias = ()
        perdidas_ajenas = Perdida.objects.all()
    
    return render(request, r'perdida\perdida.html', {"perdidas_mias": perdidas_mias, "perdidas_ajenas": perdidas_ajenas})





def ver_perro_perdida(request, id):
    perdida=Perdida.objects.get(id=id)
    puedoEditar = False
    if request.user.is_authenticated:
        puedoEditar = ((perdida.email_autor == request.user.email) | request.user.is_superuser )
    print(f"perdida {perdida.nombre} es del usuario: {perdida.email_autor}")
    return render(request, r'perdida\ver_perro_perdida.html', {"perdida": perdida, 'puedoEditar':puedoEditar})


def crear_perdida(request):
    if request.method == 'POST':
        form = PerdidaForm(request.POST, request.FILES)
        if form.is_valid():
            form.instance.email_autor = request.user.email
            form.save()
            messages.add_message(request=request,level=messages.SUCCESS, message="Perro perdido creado con éxito.")
            return redirect('Perdida')
        else:
             messages.add_message(request=request,level=messages.SUCCESS, message="Perro perdido no se ha podido crear.")
    else:
        form = PerdidaForm()
    
    return render(request, r'perdida/form_crear_perdida.html', {'form': form})

def perro_encontrado(request,id):
    perro=get_object_or_404(Perdida,id=id)
    if perro:
        perro.encontrado=True
        perro.save()
        print("PERRO ENCONTRADO")
        print(perro.encontrado)
    return redirect('Perdida')  




def editar_perdida(request,id):
    perdida = get_object_or_404(Perdida, id=id)
    if perdida is None:
        print('la perdida no existe')
        return redirect('Perdida')
    
    if request.method == 'POST':
        form = EditarPerdidaForm(request.POST, instance=perdida)
        if form.is_valid():
            form.instance.email_autor = request.user.email
            form.instance.created = perdida.created
            form.instance.imagen = perdida.imagen #ya que no es editable, de todas formas la reasignamos por si se borra.
            form.save()
            return redirect('Perdida')
        else:
            messages.error(request, 'Error en los datos ingresados.')
    else:
        form = EditarPerdidaForm(instance=perdida)

    return render(request, r'perdida/editar_perdida.html', {'perdida':perdida, 'form':form})


def eliminar_perdida(request,id):
    perdida = get_object_or_404(Perdida, id=id)
    if request.method == 'POST':
        if 'confirmar' in request.POST:
            perdida.delete()
        return redirect('Perdida')
    
    return render(request, r'perdida/eliminar_perdida.html', {'perdida':perdida})
