from django.urls import path
from django.conf import settings
from . import views
from django.conf.urls.static import static

urlpatterns = [
    path('',views.listar_perdidas,name='Perdida'),
    path('ver_perro_perdida/', views.ver_perro_perdida, name='ver_perro_perdida'),
    path('ver_perro_perdida/<str:id>/', views.ver_perro_perdida, name='ver_perro_perdida'),
#tener en cuenta que es el name es el referenciable desde el html, como por ej: desde el nav.

    path('crear_perdida/', views.crear_perdida, name='Crear_perdida'),
    path('perro_encontrado/<str:id>', views.perro_encontrado, name='perro_encontrado'),

    
    path('editar_perdida/<str:id>/', views.editar_perdida, name='editar_perdida'),
    path('eliminar_perdida/<str:id>/', views.eliminar_perdida, name='eliminar_perdida'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

