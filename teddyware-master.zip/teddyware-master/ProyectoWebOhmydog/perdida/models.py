from django.db import models
import os
from ProyectoWebOhmydog.settings import MEDIA_ROOT
from django.contrib.auth.models import User
from django.conf import settings

# Create your models here.
class Perdida(models.Model):
    
    def default_image():
        return os.path.join(MEDIA_ROOT, 'defaults/perro.jpg')

    GENEROS_DISPONIBLES = [
        ('macho', 'Macho'),
        ('hembra', 'Hembra'),
    ]

    id=models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=30, default="Perro sin nombre")
    raza=models.CharField(max_length=50, default="Sin Raza")
    descripcion = models.CharField(max_length=240) #interesante saber que si desde el panel de admin le queremos cargar algo que supere la maxima longitud de caracteres, automaticamente lo recorta.
    encontrado = models.BooleanField(auto_created=False, default=False)
    genero = models.CharField(max_length=20, choices=GENEROS_DISPONIBLES, null=False, blank=False)
    zona = models.CharField(max_length=50, blank=False, null=False) 
    created = models.DateTimeField(auto_now_add=True) #seria cuando se perdio asi que podrian setearlo a gusto
    updated = models.DateTimeField(blank=True, null=True)
    imagen = models.ImageField(blank=True, null=True, upload_to='perros_perdidos', default="defaults/perro.jpg")
    email_autor= models.EmailField(null=False,blank=False)

    class Meta:
        verbose_name='Perdida'
        verbose_name_plural='Perdidas'

    def __str__(self):
        if(self.encontrado):
            auxStringEstado="Encontrado"
        else:
            auxStringEstado="En busqueda"
        #la variable auxStringEstado solo es usada para no imprimir "true/false", sino algo mas explicito.
        return f"Nombre: {self.nombre}, estado: {auxStringEstado}, descripcion: {self.descripcion}"
    
    def isEncontrado(self):
        return self.encontrado
    
