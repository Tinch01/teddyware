from django import forms
from .models import Perdida
from django.utils import timezone
from django.db import models



class PerdidaForm(forms.ModelForm):
    nombre = forms.CharField(required=False, label="Nombre del perro (Solo si lo conoce)")
    raza = forms.CharField(required=False, label="Raza(Solo si tiene)")

    class Meta:
        model = Perdida
        exclude = ['encontrado','updated','email_autor']


    def save(self, *args, **kwargs):
        self.instance.updated = timezone.now()  # Actualizar el campo `updated` con la fecha y hora actual
        self.instance.created = timezone.now()  # Actualizar el campo `updated` con la fecha y hora actual
        super().save(*args, **kwargs)  # Llamar al método `save()` original para guardar el modelo

    def clean_nombre(self):
        valor_predeterminado = 'Perro sin nombre'
        campo_vacio = self.cleaned_data['nombre']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
        
#    si no se ingresa raza se guarda el valor por defecto:
    def clean_raza(self):
        valor_predeterminado = 'Sin Raza'
        campo_vacio = self.cleaned_data['raza']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado


# EL DE EDITAR ====================================================================================================================================
class EditarPerdidaForm(forms.ModelForm):
    nombre = forms.CharField(required=False, label="Nombre del perro (Solo si lo conoce)")
    raza = forms.CharField(required=False, label="Raza(Solo si tiene)")

    class Meta:
        model = Perdida        
        fields = "__all__"
        exclude = [ 'imagen','updated','email_autor']

    def save(self, *args, **kwargs):
        instance = kwargs.get('instance')
        self.instance.updated = timezone.now()  # Actualizar el campo `updated` con la fecha y hora actual
        super().save(*args, **kwargs)  # Llamar al método `save()` original para guardar el modelo

    def clean_nombre(self):
        valor_predeterminado = 'Perro sin nombre'
        campo_vacio = self.cleaned_data['nombre']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
        
#    si no se ingresa raza se guarda el valor por defecto:
    def clean_raza(self):
        valor_predeterminado = 'Sin Raza'
        campo_vacio = self.cleaned_data['raza']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
            