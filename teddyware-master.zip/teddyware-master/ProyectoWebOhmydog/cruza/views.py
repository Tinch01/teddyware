from django.shortcuts import render,redirect,get_object_or_404
from .models import Cruza, PropuestaCruza
from .forms import ElegirPerroForm
from django.db.models import Q
from perro.models import Perros
from django.contrib import messages
from .forms import PublicarCruzaForm,SolicitarContactoForm,ElegirPerroForm,EditarCruzaForm



#vista principal de la seccion
#Muestra un seleccionador de perros del usuario y listará los perros "COMPATIBLES" para cruzar con este.

def menuCruza(request):
    return render(request, r'cruza/menu_cruza.html')

def listarCruzasTodas(request):
    cruzasAListar = Cruza.objects.all()
    return render(request, r'cruza/listar_cruzas_todas.html', {'cruzasAListar' : cruzasAListar})
        

def listarCruzasRecomendacion(request):
    cruzasAListar = None
    if request.method == 'POST':
        form = ElegirPerroForm(request.POST, user=request.user)
        if form.is_valid():
            perro_seleccionado_id = form.cleaned_data['perro'] #guardo el id del perro seleccionado, que es lo que quedo en el formulario.
            perro_seleccionado = Perros.objects.get(id=perro_seleccionado_id) #a partir d eese id ahora recupero al perro entero. Puedo usarlo para el resto que necesite.

            #Obtengo todas las cruzas que sean compatibles con el perro elegido:
            # MISMA RAZA Y MISMO TAMANIO.
            # EXCLUYO LOS QUE SEAN MIOS, NO LOS MUESTRO.
            # EXCLUYO LOS DEL MISMO GENERO, NO LOS MUESTRO.

            cruzasAListar = Cruza.objects.filter(
                Q(perro__raza__icontains=perro_seleccionado.raza) &
                Q(perro__tamanio=perro_seleccionado.tamanio) &
                ~Q(perro__dueno=perro_seleccionado.dueno) &
                ~Q(perro__genero=perro_seleccionado.genero)
            )
            #No importa cuales filtros hayamos hechos, dejo para lo ultimo REMOVER LAS PUBLICACIONES PROPIAS
            return render(request, r'cruza/listar_cruzas_recomendacion.html', {'form': form, 'cruzasAListar' : cruzasAListar, 'perro_seleccionado' : perro_seleccionado})
        
    else:
        form = ElegirPerroForm(user=request.user)

    return render(request, r'cruza/listar_cruzas_recomendacion.html', {'form': form, 'cruzasAListar': cruzasAListar})

def misCruzas(request):
    #fallando: siempre quedan vacias, asi que deberia fijarme como se esrtan guardando estas solicitudes.
    # 2: ver que se guarden bien en el diccionario de vuelta.
    cruzas_del_cliente = Cruza.objects.filter(perro__dueno__email=request.user.email)
    cruzas_y_candidatos = {}  
    
    for cruza in cruzas_del_cliente:
        print('======')
        print(cruza)
        print('propuestas de este:')
        
        if cruza.interesados is not None:
            print("true")
            cruzas_y_candidatos[cruza] = cruza.interesados.all()
        else:
            print("else")
            cruzas_y_candidatos[cruza] = None

    print("cruzas_y_candidatos...")
    print(cruzas_y_candidatos)

    return render(request, 'cruza/mis_cruzas.html', {'cruzas_del_cliente':cruzas_del_cliente, 'cruzas_y_candidatos': cruzas_y_candidatos})

    
def publicarCruza(request):
    if request.method == 'POST':
        form = PublicarCruzaForm(request.POST, user=request.user)
        if form.is_valid():
            perro_seleccionado_id = form.cleaned_data['perro'] #guardo el id del perro seleccionado, que es lo que quedo en el formulario.
            if (Cruza.objects.filter(perro_id=perro_seleccionado_id).exists()): #controlo si esta repetido;
                messages.error(request, 'El perro %s ya se encuentra publicado para cruza!. No puedes estar publicarlo para cruza si ya lo está.' %(Perros.objects.get(id=perro_seleccionado_id)))
                # lo mismo para mas posibles reglas de negocio!...
                # if (Cruza.objects.filter(CONDICION1 ): #controlo condicion1;
                #       messages.error(request, 'El perro %s No comple con la condicion1!.' %(Perros.objects.get(perro__id=perro_seleccionado_id)))                
            else:
                form.save()  # Guarda los datos en la base de datos
                messages.success(request, 'El perro %s se ha publicado para cruza.'  %(Perros.objects.get(id=perro_seleccionado_id.id))  )
                return redirect('Ver_mis_cruzas')
            #en este caso, se complete o no el registro, se quedara en la misma pagina, informando con un mensaje segun corresponda.
            return render(request, r'cruza/form_publicar_cruza.html', {'form': form})            
    else:
        form = PublicarCruzaForm(user=request.user)
    
    return render(request, r'cruza/form_publicar_cruza.html', {'form': form})


def verCruza(request, id):
    cruza=Cruza.objects.get(id=id)
    
    ya_habia_solicitado_contacto = False
    # if cruza.interesados is not None:
    #     propuestas = cruza.interesados.all()
    #     for propuesta in propuestas:
    #         if (propuesta.perro_interesado.duenio.email == request.user.email):
    #             ya_habia_solicitado_contacto = True
    #             print("GRANDOTE")
    #             print(propuesta)
    #             print('es del duenio: ')
    #             print(propuesta.perro_interesado.duenio.email)
    #             break

    puedo_editar = False
    if (request.user.is_superuser or (request.user.email == cruza.perro.dueno.email)):
        puedo_editar=True
    
    return render(request, r'cruza/ver_cruza.html', {'cruza': cruza, 'puedo_editar':puedo_editar, 'ya_habia_solicitado_contacto': ya_habia_solicitado_contacto})



def contactar_cruza(request,id):
    cruza = Cruza.objects.get(id=id)
    if request.method == 'POST':
        form = SolicitarContactoForm(request.POST, user=request.user)
        if form.is_valid():
            perro_seleccionado_id = form.cleaned_data['perro_interesado'].id #guardo el id del perro seleccionado, que es lo que quedo en el formulario.
            
            form.save()  # Guarda los datos en la base de datos
            # if cruza.interesados is not None: 
            #     if (cruza.interesados.filter(perro_interesado__id=perro_seleccionado_id).exists() ):
            #         messages.error(request, 'Error, ya has solicitado contactarte con este perro.' )
            # else:
            #     form.save()  # Guarda los datos en la base de datos
            #     messages.success(request, 'La solicitud de contacto se envió con éxito.')

    else:
        form = SolicitarContactoForm(user=request.user)
    
    return render(request, r'cruza/form_postularse_para_contacto.html', {'form': form, 'cruza':cruza})



def editar_cruza(request,id):
    cruza = get_object_or_404(Cruza, id=id)

    if request.method == 'POST':
        form = EditarCruzaForm(request.POST, instance=cruza)
        if form.is_valid():
            form.save()
            return redirect('Ver_mis_cruzas')
        else:
            messages.error(request, 'Error en los datos ingresados.')
    else:
        form = EditarCruzaForm(instance=cruza)

    return render(request, r'cruza/editar_cruza.html', {'cruza':cruza, 'form':form})


def eliminar_cruza(request,id):
    cruza = get_object_or_404(Cruza, id=id)

    if request.method == 'POST':
        if 'confirmar' in request.POST:
            cruza.delete()
        return redirect('Ver_mis_cruzas')
    
    return render(request, r'cruza/eliminar_cruza.html', {'cruza':cruza})
