from django import forms
from perro.models import Perros
from .models import Cruza,PropuestaCruza

# utilizado para elegir el perro del cual queremos que se listen sus cruzas compatibles.
class ElegirPerroForm(forms.Form):

    perro = forms.ChoiceField(label='Seleccion de perro:') #label='Nombre personalizado del campo')

    def __init__(self, *args, **kwargs):
        filtered_objects=None
        usuario = kwargs.pop('user', None)
        super(ElegirPerroForm, self).__init__(*args, **kwargs)
        if usuario:
            filtered_objects = Perros.objects.filter(dueno__email=usuario.email)
        choices_list = []
        for obj in filtered_objects:
            choices_list.append((obj.id, obj.nombre))  # Ajusta los atributos "id" y "nombre" según tu modelo
        self.fields['perro'].choices = choices_list




class PublicarCruzaForm(forms.ModelForm):
    perro = forms.ModelChoiceField(queryset=Perros.objects.none(), label="Seleccione perro a publicar:")

    class Meta:
        model = Cruza
        fields = ['perro', 'descripcion']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 9}),
        }
        exclude = ['interesados']

    def __init__(self, *args, **kwargs):
        usuario = kwargs.pop('user', None)
        super(PublicarCruzaForm, self).__init__(*args, **kwargs)
        if usuario:
            filtered_objects = Perros.objects.filter(dueno__email=usuario.email)
            self.fields['perro'].queryset = filtered_objects



class SolicitarContactoForm(forms.ModelForm):
    perro_interesado = forms.ModelChoiceField(queryset=Perros.objects.none(), label="Seleccione cual perro desea postular:")
    
    class Meta:
        model = PropuestaCruza
        fields = ['perro_interesado', 'mensaje']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 9}),
        }

    def __init__(self, *args, **kwargs):
        usuario = kwargs.pop('user', None)
        super(SolicitarContactoForm, self).__init__(*args, **kwargs)
        if usuario:
            filtered_objects = Perros.objects.filter(dueno__email=usuario.email)
            self.fields['perro_interesado'].queryset = filtered_objects


class EditarCruzaForm(forms.ModelForm):
    class Meta:
        model = Cruza
        fields = ['descripcion']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 9}),
        }