from django.db import models
from perro.models import Perros


class PropuestaCruza(models.Model):
    ESTADOS_DISPONIBLES = [
        ('pendiente', 'Pendiente'),
        ('aceptado', 'Aceptado'),
        ('rechazado', 'Rechazado'),
    ]

    perro_interesado = models.OneToOneField(Perros, on_delete=models.SET_NULL,null=True, blank=True)
    mensaje =  models.CharField(max_length=500)
    estado = models.CharField(max_length=200, choices=ESTADOS_DISPONIBLES, default='Pendiente', null=False, blank=False)
    
    def __str__(self):
        return (f'PROPUESTA: {self.perro_interesado}, {self.mensaje}, {self.estado}')
    

class Cruza(models.Model):
    perro = models.OneToOneField(Perros, on_delete=models.CASCADE, null=True, blank=False)
    descripcion = models.CharField(max_length=500)
    #aquellos que quieren contactarse, eligen un perro y piden "contactarse", ese perro interesado en cruza para este perro se guarda en: 
    interesados = models.ForeignKey(PropuestaCruza, related_name='publicaciones_interes', on_delete=models.SET_NULL, null=True, blank=True)
   
    #lo usa para el filtrado y demas cosas que podemos ajustar.
    # objects = MyModelManager()

    def __str__(self):
        return (f'CRUZA: {self.perro}, {self.descripcion}')
    
