
from django.urls import path
from usuario.views import *
from . import views


urlpatterns = [
    path('', views.menuCruza, name = 'Cruza'),
    path('listar_cruzas_todas/', views.listarCruzasTodas, name = 'Listar_cruzas_todas'),
    path('listar_cruzas_recomendacion/', views.listarCruzasRecomendacion, name = 'Listar_cruzas_recomendacion'),
    path('ver_mis_cruzas/', views.misCruzas, name='Ver_mis_cruzas'),
    path('publicar_cruza/', views.publicarCruza, name='Publicar_cruza'),
    path('ver_cruza/<str:id>/', views.verCruza, name='Ver_Cruza'),
    path('contactar/<int:id>/', views.contactar_cruza, name='contactar_cruza'),
    path('editar_cruza/<int:id>/', views.editar_cruza, name='editar_cruza'),
    path('eliminar_cruza/<int:id>/', views.eliminar_cruza, name='eliminar_cruza'),

]
