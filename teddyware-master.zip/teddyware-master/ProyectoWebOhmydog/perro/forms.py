from django import forms  
from perro.models import Perros , Episodios
from django.contrib.auth.models import User
from datetime import date, timedelta
from django.core.exceptions import ValidationError



class PerrosForm(forms.ModelForm):  
    
    nacimiento=forms.DateField(label='Fecha de nacimiento', widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), initial=date.today() + timedelta(days=1))

    class Meta:  
        model = Perros  
        fields = ['nombre', 'dueno', 'raza', 'nacimiento', 'tamanio','genero' ]

    def clean_nacimiento(self):
        nacimiento = self.cleaned_data.get('nacimiento')
        if nacimiento and nacimiento > date.today():
            raise forms.ValidationError("Seleccione una fecha pasada")
        return nacimiento

    def clean_dueno(self):
        dueno = self.cleaned_data.get('dueno')
        nombre = self.cleaned_data.get('nombre')
        # Verificar si el usuario ya tiene un perro con el mismo nombre
        if nombre and dueno:
            perros_existentes = Perros.objects.filter(dueno=dueno, nombre=nombre)
            if perros_existentes.exists():
                raise ValidationError("El usuario ya posee un perro con este nombre.")

        return dueno
    



class FormularioPerro(forms.ModelForm):

    nacimiento=forms.DateField(label='Fecha de nacimiento', widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), initial=Perros.nacimiento)

    class Meta:  
        model = Perros  
        fields = ['nombre', 'dueno', 'raza', 'nacimiento', 'tamanio', 'genero' ] 

    def clean_nacimiento(self):
        nacimiento = self.cleaned_data.get('nacimiento')
        if nacimiento and nacimiento > date.today():
            raise forms.ValidationError("Seleccione una fecha pasada")
        return nacimiento
    
    """def clean_dueno(self):
        dueno = self.cleaned_data.get('dueno')
        nombre = self.cleaned_data.get('nombre')
        # Verificar si el usuario ya tiene un perro con el mismo nombre
        if nombre and dueno:
            perros_existentes = Perros.objects.filter(dueno=dueno, nombre=nombre).count()
            if perros_existentes> 2:
                raise ValidationError("El usuario ya posee un perro con ese nombre.")

        return dueno"""
    
    def clean(self):
        cleaned_data = super().clean()
        dueno = cleaned_data.get('dueno')
        nombre = cleaned_data.get('nombre')

        if nombre and dueno:
            perros_existentes = Perros.objects.filter(dueno=dueno, nombre=nombre).count()
            if perros_existentes >= 1:
                raise forms.ValidationError("El usuario ya posee un perro con ese nombre.")

        return cleaned_data
    

#para editar habria que hacer un Form especifico, y en el sacarle este initial del campo fecha, asi creo que agarraria el instance.fecha
class EpisodioForm(forms.ModelForm):
    fecha=forms.DateField(label='Fecha de nacimiento', widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), initial=date.today() + timedelta(days=1))

    class Meta:
        model = Episodios
        fields = ['perro', 'fecha', 'diagnostico', 'pronostico', 'tratamiento', 'detalles',]
        widgets = {
            'perro': forms.HiddenInput(attrs={'readonly': True})
        }
       
#    si no se ingresa nombre se guarda el valor por defecto:
    def clean_detalles(self):
        valor_predeterminado = 'Sin detalles'
        campo_vacio = self.cleaned_data['detalles']
        if campo_vacio:
            return campo_vacio
        else:
            return valor_predeterminado
    