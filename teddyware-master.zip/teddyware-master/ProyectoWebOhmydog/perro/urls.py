from django.urls import path
from .views import *
from . import views
urlpatterns = [ 
    path('mis_perros', view_listar_perros, name="Ver_mis_perros"),#cuando un usuario quiere ver sus perroe
    path('registrar_perro',view_registrar_perro.as_view(), name="Registrar_perro"), #CUANDO UN ADMIN quiere registrarle un perro a un usuario.
    path('ver_historial_clinico/', views.ver_historial_clinico, name='ver_historial_clinico'),
    path('ver_historial_clinico/<str:id>/', views.ver_historial_clinico, name='ver_historial_clinico'),
    path('editar_eliminar_perro', editar_eliminar_perro, name="editar_eliminar_perro"), 
    path('editar_perro/<str:id>/', editar_perro, name='editar_perro'),
    path('eliminar_perro/<str:id>/', eliminar_perro, name='eliminar_perro'),
    path('agregar_episodio/<str:id>/', agregar_episodio, name='agregar_episodio'),
    path('editar_episodio/<str:episodio_id>/', editar_episodio, name='editar_episodio'),
    path('eliminar_episodio/<str:episodio_id>/', eliminar_episodio, name='eliminar_episodio'),

]

