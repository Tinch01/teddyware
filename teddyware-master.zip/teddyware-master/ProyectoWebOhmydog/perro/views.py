from django.shortcuts import render,redirect, get_object_or_404
from .forms import *
from .models import Perros
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Episodios, Perros

from django.contrib.auth.decorators import login_required
# Create your views here.


# def view_registrar_perro(request):
#     form = PerrosForm()
#     return render(request, r"perro/registrar_perro.html",{"form":form})



def view_listar_perros(request):
    #las guardo en una lista para pasarsela al html.
    perros_del_cliente = Perros.objects.filter(dueno = request.user) #Primero guardo todos los perros del cliente
    #Los prints en consola son de cuando estaba probando.
    print(request.user.username)
    print(request.user.first_name)
    print(request.user.email)
    print('cantidad de perros del cliente: %s' %(perros_del_cliente.count()))
    print('Perros a continuacion:')
    print(perros_del_cliente)
    return render(request, r'perros\listar_mis_perros.html', {'perros_del_cliente': perros_del_cliente})


from django.views.generic.edit import CreateView
from .models import Perros

from datetime import datetime, timedelta
def ver_historial_clinico(request, id):
    perro= Perros.objects.get(id=id)
    dueno=perro.dueno
    historial_clinico=Episodios.objects.filter(perro=perro)

    
    return render(request, r'perros/ver_historial_clinico.html', {'perro': perro,'dueno': dueno, 'historial_clinico': historial_clinico})


def editar_eliminar_perro(request):
    perros= Perros.objects.all()
    return render(request, r'perros/editar_eliminar_perros.html', {'perros': perros})

def editar_perro(request, id):
    perro = get_object_or_404(Perros, id=id)

    if request.method == 'POST':
        formulario = FormularioPerro(request.POST, instance=perro)
        if formulario.is_valid():
            formulario.save()
            return redirect('editar_eliminar_perro')
    else:
        formulario = FormularioPerro(instance=perro)

    return render(request, 'perros/editar_perro.html', {'formulario': formulario})

def eliminar_perro(request, id):
    perro = get_object_or_404(Perros, id=id)
    
    if request.method == 'POST':
        if 'confirmar' in request.POST:
            perro.delete()
        return redirect('editar_eliminar_perro')
    
    context = {
        'perro': perro
    }
    
    return render(request, 'perros/eliminar_perro.html', context)

def agregar_episodio(request, id):
    if request.method == 'POST':
        form = EpisodioForm(request.POST)
        if form.is_valid():
            episodio = form.save(commit=False)
            perro = Perros.objects.get(id=id)
            episodio.perro = perro
            episodio.save()
            return redirect('ver_historial_clinico', perro.id)  # Reemplaza con la ruta correcta del historial clínico
    else:
        perro = Perros.objects.get(id=id)  # Reemplaza con la lógica para obtener el perro correcto
        form = EpisodioForm(initial={'perro': perro})
    return render(request, 'perros/agregar_episodio.html', {'form': form})

def editar_episodio(request, episodio_id):
  episodio = Episodios.objects.get(id=episodio_id)
  if request.method == 'POST':
    form = EpisodioForm(request.POST, instance=episodio)
    if form.is_valid():
      form.save()
      return redirect('ver_historial_clinico', episodio.perro.id)  # Reemplaza con la ruta correcta del historial clínico
  else:
    form = EpisodioForm(instance=episodio)

  return render(request, 'perros/editar_episodio.html', {'form': form})



def eliminar_episodio(request, episodio_id):
  episodio = get_object_or_404(Episodios, id=episodio_id)
  if request.method == 'POST':
    episodio.delete()
    return redirect('ver_historial_clinico', episodio.perro.id)  # Reemplaza con la ruta correcta del historial clínico
  return render(request, 'perros/eliminar_episodio.html', {'episodio': episodio})

class view_registrar_perro(CreateView): #en chatgpt era la MyModelCreateView(CreateView)
    model = Perros
    #ahora definis los campos que queres que el formulario tenga: ejemplo:   # fields = ['name', 'raza']
    #pero como queremos todos: ahi va con este atajo:
    #fields = '__all__' 
    form_class = PerrosForm
    template_name = r"perros\form_registrar_perro.html"
    

    def form_valid(self, form):
        # Guardar el formulario y realizar acciones adicionales si es necesario
        self.object = form.save()

        messages.success(self.request, 'Perro %s registrado con éxito para el usuario %s.' %(form.cleaned_data['nombre'], form.cleaned_data['dueno']))
        # Redirigir al usuario a la página de inicio ('Home')
        return redirect('Registrar_perro')

    
