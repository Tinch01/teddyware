from django.db import models
from django.contrib.auth.models import User
from datetime import date,timedelta

class Perros(models.Model):

    TAMANIOS_DISPONIBLES = [
        ('pequenio', 'Pequenio'),
        ('mediano', 'Mediano'),
        ('grande', 'Grande'),
    ]

    GENEROS_DISPONIBLES = [
        ('macho', 'Macho'),
        ('hembra', 'Hembra'),
    ]

    nombre = models.CharField(max_length=30)
    raza = models.CharField(max_length=30)
    nacimiento = models.DateField()
    dueno = models.ForeignKey(User, on_delete=models.CASCADE)
    tamanio = models.CharField(max_length=20, choices=TAMANIOS_DISPONIBLES, null=False, blank=False)
    genero = models.CharField(max_length=20, choices=GENEROS_DISPONIBLES, null=False, blank=False)

    def __str__(self):
        return (self.nombre)
    
    def edad(self):
        hoy = date.today()
        edad = hoy.year - self.nacimiento.year
        if hoy.month < self.nacimiento.month or (hoy.month == self.nacimiento.month and hoy.day < self.nacimiento.day):
            edad -= 1
        return edad
    

class Episodios(models.Model):
    
    perro=models.ForeignKey(Perros, on_delete=models.CASCADE, default="")
    diagnostico=models.CharField(max_length=256, blank=False, null=False)
    pronostico=models.CharField(max_length=256, blank=False, null=False)
    tratamiento=models.CharField(max_length=256, blank=False, null=False)
    detalles=models.CharField(max_length=256, blank=True, null=True,default="")
    fecha=models.DateField(blank=False, null=False)

    def is_editable(self):
        dias_pasados = date.today() - self.fecha
        if dias_pasados <= timedelta(days=15):
            return True
        else:
            return False