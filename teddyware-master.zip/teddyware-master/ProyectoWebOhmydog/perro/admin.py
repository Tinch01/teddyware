from django.contrib import admin
from perro.models import Perros, Episodios


class PerrosAdmin(admin.ModelAdmin,):
    list_filter=("raza", "raza")
    
admin.site.register(Perros, PerrosAdmin)

admin.site.register(Episodios)