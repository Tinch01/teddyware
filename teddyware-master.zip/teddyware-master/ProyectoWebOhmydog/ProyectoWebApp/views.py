from django.http import HttpResponse
from django.shortcuts import render
from servicios.models import Paseador_Cuidador
from adopcion.models import Adopcion
# Create your views here.



def home(request):
    return render(request, r"ProyectoWebApp\home.html")

#Separadas por funcionalidad: =========================================================================

#manejo de usuarios


#Solicitud de turnos 
def turnos(request):
    return render(request, r"ProyectoWebApp\turnos.html")


# BORRADO PORQUE YA FUE MUDE A SU APP.


#Donaciones ( colectas )
def donacion(request):
    return render(request, r"ProyectoWebApp\donacion.html")


#veterinarias de turno 
def veterinariasDeTurno(request):
    return render(request, r"ProyectoWebApp\veterinarias_de_turno.html")

#Informacion adicional
def quienesSomos(request):
    return render(request, r"ProyectoWebApp\quienes_somos.html")


def preguntasFrecuentes(request):
    return render(request, r"ProyectoWebApp\preguntas_frecuentes.html")


#extra
def sitioEnConstruccion(request):
    return render(request, r"ProyectoWebApp\sitio_en_construccion.html")
    #aca pueden agruparse todas aquellas urls que aun no poseen su pagina construida, entonces no tener html incompleto al alcance de las urls.
    #otra posibilidad para lo mismo seria, que el html correspondiente a cada una, extienda del html de sitio en 
