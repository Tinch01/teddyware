from django.urls import path, include
from ProyectoWebApp import views
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

# primero la url que se usara desde el navegador. 
# segundo la funcion que se encargadra del request.
# "Name=" se usa para ... proporcionarle esa referencia, por ejemplo desde el nav llamamos a estas con {% url 'Home' %} y asi con todas.

urlpatterns = [
    path('',views.home, name="Home"), #no tiene url porque seria la del sitio. 
    path('adopcion/', include('adopcion.urls'), name="Adopcion"),
    path('turnos/',include('turnos.urls'), name="Menu_turnos"),
    path('preguntasfrecuentes/',views.preguntasFrecuentes, name="Preguntas_frecuentes"),
    path('quienesSomos/',views.quienesSomos, name="Quienes_somos"),
    path('servicios/', include('servicios.urls'), name="Servicios"),
    path('veterinariasdeturno/',views.veterinariasDeTurno, name="VeterinariasDeTurno"),
    path('admin/', admin.site.urls),
    path('perro/',include('perro.urls'), name="perro"),

    path('turnos/', include('turnos.urls'), name="Turnos"),
    path('cruza/', include('cruza.urls'), name="Cruza"),

    path('perdida/',include('perdida.urls'), name="Perdida"),

]

urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)