from django.contrib.auth.models import AbstractUser
from django.db import models



#COMO LO HICE:
# https://www.youtube.com/watch?v=x0f4guW1zuA

#Esta bueno saber que no me dejo cambiar "unique=True" (fallaba la migration) hasta que borré los usuarios que tenian el mismo correo asignado!.
#Faltaria asignarle las caracteristicas de key no se qué si no me equivoco.


#Notese que no puse: NOMBRE ni APELLIDO, porque ya vienen incluidas en el AbstractUser, 
# si las volvemos a definir es solo si le queremos modificar el comportamiento,(como ocurre con el campo email que tambien es heredado)

