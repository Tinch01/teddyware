from django.shortcuts import render,redirect,get_object_or_404
from servicios.models import Paseador_Cuidador
from .forms import Paseador_Cuidador, Editar_Paseador_CuidadorForm
from django.contrib import messages
# Create your views here.


#Servicios ( paseadores y cuidadores ) 
def listar_servicios(request):
    servicios= Paseador_Cuidador.objects.all()
    return render(request, r"servicios/listar_servicios.html", {"servicios": servicios})


def ver_perfil(request, id):
    servicio= Paseador_Cuidador.objects.get(id=id)
    return render(request, r'servicios/ver_servicio.html', {'servicio': servicio})


from .forms import Paseador_CuidadorForm
def view_crear_servicio(request):
    if request.method == 'POST':
        form = Paseador_CuidadorForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()  # Guarda los datos en la base de datos
            return redirect('Servicios') # si logueo correctamente, te redirije al listado de adopciones
    else:
        form = Paseador_CuidadorForm()
    return render(request, r'servicios/form_crear_servicio.html', {'form':form})
    


# no permite editar foto!
def editar_servicio(request,id):
    servicio = get_object_or_404(Paseador_Cuidador, id=id)

    if request.method == 'POST':
        form = Editar_Paseador_CuidadorForm(request.POST, request.FILES, instance=servicio)
        if form.is_valid():
            form.save()
            return redirect('ver_perfil',id)
        else:
            messages.error(request, 'Error en los datos ingresados.')
    else:
        form = Editar_Paseador_CuidadorForm(instance=servicio)

    return render(request, r'servicios/editar_servicio.html', {'servicio':servicio, 'form':form})


def eliminar_servicio(request,id):
    servicio = get_object_or_404(Paseador_Cuidador, id=id)
    if request.method == 'POST':
        if 'confirmar' in request.POST:
            servicio.delete()
        return redirect('Servicios')
    
    return render(request, r'servicios/eliminar_servicio.html', {'servicio':servicio})

