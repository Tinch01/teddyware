from django.contrib import admin
from .models import Paseador_Cuidador

#Con esta no hay problema, es posible usarlas!.
admin.site.register(Paseador_Cuidador)