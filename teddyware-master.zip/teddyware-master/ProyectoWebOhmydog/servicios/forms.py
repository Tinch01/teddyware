from django import forms
from .models import Paseador_Cuidador

class Paseador_CuidadorForm(forms.ModelForm):
    class Meta:
        model = Paseador_Cuidador        
        fields = "__all__"

from django import forms
from .models import Paseador_Cuidador

class Editar_Paseador_CuidadorForm(forms.ModelForm):
    class Meta:
        model = Paseador_Cuidador        
        fields = "__all__"
        exclude = [ 'foto']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        instance = kwargs.get('instance')
        if instance:
            self.fields['nombre'].initial = instance.nombre
            self.fields['apellido'].initial = instance.apellido
            self.fields['email'].initial = instance.email
            self.fields['telefono'].initial = instance.telefono
            self.fields['detalles'].initial = instance.detalles
            self.fields['zona'].initial = instance.zona
            self.fields['dias_disponibles'].initial = instance.dias_disponibles
            self.fields['tipo'].initial = instance.tipo
            
#     nombre=models.CharField(max_length=30)
#     apellido=models.CharField(max_length=30)
#     email=models.EmailField(unique=True)
#     telefono=models.CharField(max_length=12, unique=True)
#     detalles=models.CharField(max_length=256, default='')
#     zona=models.CharField(max_length=30, default='La Plata')
#     dias_disponibles=MultiSelectField(max_length=100, choices=DIA_SEMANA_CHOICES, default='')
#     tipo=MultiSelectField(max_length=10, choices=TIPO_CHOICES, default='P', blank=False)
#     foto=models.ImageField(blank=True, null=True, upload_to='paseadores_cuidadores', default="defaults/usuario.jpg")