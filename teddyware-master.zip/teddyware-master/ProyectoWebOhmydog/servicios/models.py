from django.db import models
import os
from ProyectoWebOhmydog.settings import MEDIA_ROOT
from multiselectfield import MultiSelectField

# Create your models here.

class Paseador_Cuidador(models.Model):

    DIA_SEMANA_CHOICES = [
        ('Lunes', 'Lunes'),
        ('Martes', 'Martes'),
        ('Miércoles', 'Miércoles'),
        ('Jueves', 'Jueves'),
        ('Viernes', 'Viernes'),
        ('Sábado', 'Sábado'),
        ('Domingo', 'Domingo'),
    ]

    TIPO_CHOICES = [
        ('Paseador', 'Paseador'),
        ('Cuidador', 'Cuidador'),

    ]


    def __str__(self):
         return self.nombre

    def default_image():
        return os.path.join(MEDIA_ROOT, 'defaults/usuario.jpg')
    
    id=models.AutoField(primary_key=True)
    nombre=models.CharField(max_length=30)
    apellido=models.CharField(max_length=30)
    email=models.EmailField(unique=True)
    telefono=models.CharField(max_length=12, unique=True)
    detalles=models.CharField(max_length=256, default='')
    zona=models.CharField(max_length=30, default='La Plata')
    dias_disponibles=MultiSelectField(max_length=100, choices=DIA_SEMANA_CHOICES, default='')
    tipo=MultiSelectField(max_length=100, choices=TIPO_CHOICES, default='Paseador', blank=False)
    foto=models.ImageField(blank=True, null=True, upload_to='paseadores_cuidadores/', default="defaults/usuario.jpg")

    class Meta:
        verbose_name= 'Paseador/Cuidador'
        verbose_name_plural= 'Paseadores y cuidadores'

    
    
    