from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from usuario.views import *
from . import views


urlpatterns = [

    path('', views.listar_servicios, name='Servicios'),
    path('crear_servicio', views.view_crear_servicio, name='Crear_servicio'),
    path('ver_perfil/', views.ver_perfil, name='ver_perfil'),
    path('ver_perfil/<str:id>/', views.ver_perfil, name='ver_perfil'),
    path('editar_servicio/<str:id>/', views.editar_servicio, name='editar_servicio'),
    path('eliminar_servicio/<str:id>/', views.eliminar_servicio, name='eliminar_servicio'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)