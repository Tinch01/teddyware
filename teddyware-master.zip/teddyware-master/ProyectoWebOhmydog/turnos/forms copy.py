from django import forms
from .models import Turno
from django.forms.widgets import DateInput
from datetime import date
from django.db.models import F
from perro.models import Perros;

#es por aca, chatGPT nos dio lo mismo (para el model en particular que tenemos de Turno) y casi igual a lo que tienen los pibes.

from django.utils.translation import gettext as _
from django.utils.translation import *

class SolicitarTurnoForm(forms.ModelForm):
    # fecha=DateInput(type=date, min=str(date.today()))   PROBAR
    medico = forms.ChoiceField(choices=Turno.OPCIONES_MEDICAS)
    perro = forms.ModelChoiceField(queryset=Perros.objects.none())  # Crea queryset vacio

    class Meta:
        model = Turno
        fields = ['dia', 'medico', 'perro']        
        #probar esto de widgets despues
        # widgets = {
        #     'fecha': DateInput(attrs={'type': 'date','min': str(date.today())})
        # }

    def __init__(self, *args, **kwargs):
        usuario = kwargs.pop('usuario', None)  # Obtener el usuario del argumento 'usuario'
        super().__init__(*args, **kwargs)

        if usuario:
            self.fields['perro'].queryset = Perros.objects.filter(dueno__email=usuario.email)
        
        
class AsignarTurnoForm(forms.ModelForm):
    class Meta:
        model = Turno
        fields = ['estado']
