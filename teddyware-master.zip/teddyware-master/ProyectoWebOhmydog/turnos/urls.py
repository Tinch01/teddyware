
from django.urls import path
from usuario.views import *
from . import views
from .views import view_solicitar_turno
import threading


urlpatterns = [
    path('', views.view_menu_turnos, name='Menu_turnos'), #de moment la "raiz" de esta seccion es el formulario para pedir, cuando abramos lugar a otras partes como "ver mis turnos", "cancelar turnos", etc, ahi si podremos hacer una parte de "recepcion a sector turnos"
    path('solicitar_turno/', view_solicitar_turno.as_view(), name='Solicitar_turno'),
    
    path('ver_mis_turnos/', views.ver_mis_turnos, name='Ver_mis_turnos'),
    path('asignar_turnos_pendientes/', views.asignar_turnos_pendientes, name='Asignar_turnos_pendientes'),
    path('cancelar_turno/<str:id>', views.cancelar_turno, name='cancelar_turno'),

    path('listar_turnos_pendientes/', views.listar_turnos_pendientes, name='Listar_turnos_pendientes'),
    path('listar_turnos_aceptados/', views.listar_turnos_aceptados, name='Listar_turnos_aceptados'),
    path('listar_turnos_rechazados/', views.listar_turnos_rechazados, name='Listar_turnos_rechazados'),
    path('listar_turnos_cancelados/', views.listar_turnos_cancelados, name='Listar_turnos_cancelados'),

    path('asignar_estado_turno/<str:id>', views.asignar_estado_turno, name ='Asignar_estado_turno')
    


    # path('solicitar_turno/', views.solicitar_turno, name='solicitar_turno'),
    # path('listar_turnos_pendientes/', views.listar_turnos_pendientes, name='listar_turnos_pendientes'),
    # path('listar_turnos_confirmados/', views.listar_turnos_confirmados, name='listar_turnos_confirmados'),
    # path('listar_confirmados_dia/', views.listar_confirmados_del_dia, name='listar_confirmados_dia'),
    # path('aceptar_turno/<int:id_turno>/', views.aceptar_solicitud, name='aceptar_solicitud'),
    # path('rechazar_turno/<int:id_turno>/', views.rechazar_solicitud, name='rechazar_solicitud'),
    # path('run_scheduler/', views.run_scheduler, name='run_scheduler'),
]

# Iniciar el hilo que ejecuta el planificador al iniciar la aplicación
#threading.Thread(target=views.run_scheduler, daemon=True).start()s