from django.db import models
from perro.models import Perros

class Turno(models.Model):
    ESTADO = (
        ('Pendiente', 'Pendiente'),
        ('Aceptado', 'Aceptado'),
        ('Rechazado', 'Rechazado'),
        ('Cancelado', 'Cancelado'),
    )


    OPCIONES_MEDICAS = (
        ('Vacunacion', 'Vacunacion'),
        ('Castracion', 'Castracion'),
        ('Desparacitacion', 'Desparacitacion'),
        ('Atencion general', 'Atencion general'),
    )

    HORARIOS = (
        ('Tarde', 'Tarde'),
        ('Mañana', 'Mañana'),
    )
    
    dia = models.DateField()
    medico = models.CharField(max_length=20, choices=OPCIONES_MEDICAS)
    estado= models.CharField(max_length=20, choices=ESTADO, default='Pendiente')
    perro= models.ForeignKey(Perros, on_delete=models.CASCADE, related_name='turnos') #hacer foreign key
    franja_horaria= models.CharField(max_length=30, choices=HORARIOS, default='Mañana')
    descripcion= models.CharField(max_length=200, blank=False, null=False)

    def __str__(self):
        return f"{self.medico} el dia {self.dia} para {self.perro}, estado: {self.estado}"
    
    class Meta:
        verbose_name='Turno'
        verbose_name_plural='Turnos'

# Cuando defines un modelo en Django, puedes agregar una clase anidada llamada Meta dentro de la clase del modelo. La clase Meta define metadatos adicionales para el modelo, como su nombre en la base de datos, las restricciones de ordenamiento, los índices y más.
# Por defecto, si no se especifica una clase Meta, Django utiliza el nombre de la clase del modelo en minúsculas y en plural para determinar el nombre de la tabla en la base de datos.
# Además del db_table, la clase Meta también puede contener otras opciones, como ordering para especificar el orden de los registros en la consulta por defecto, unique_together para indicar combinaciones únicas de campos, indexes para definir índices adicionales, entre otros.
    