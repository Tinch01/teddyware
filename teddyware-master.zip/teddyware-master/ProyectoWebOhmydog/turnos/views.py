from django.shortcuts import render,get_object_or_404


#PRobando, todavia no se si funciona
from .forms import *
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from perro.models import Perros


def view_menu_turnos(request):
    return render(request, r'turnos\menu_turnos.html')

def turnos(request):
    # formulario para solicitar turno
    return render(request, r'turnos\turno_create.html')


#Haciendo copiandose del form de perro
from django.views.generic.edit import CreateView
from .models import Turno


from django.utils.translation import gettext as _
from django.utils.translation import *
class view_solicitar_turno(CreateView):
    model = Turno    
    
    #ahora definis los campos que queres que el formulario tenga: ejemplo:   # fields = ['name', 'raza']
    # fields = ['dia','medico','perro']

    #o sino le definis el Form que tengas en forms.py
    form_class = SolicitarTurnoForm
    template_name = r"turnos\form_solicitar_turno.html"
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['usuario'] = self.request.user
        return kwargs
    
    def form_valid(self, form):
        # Guardar el formulario y realizar acciones adicionales si es necesario
        self.object = form.save()
        
        # Redirigir al usuario a la página de inicio ('Home')
        return redirect('Ver_mis_turnos')  # Si logro solicitar el turno lo redirije a la seccion "ver mis turnos"



def listar_turnos_pendientes(request):
    pendientes=Turno.objects.filter(estado='Pendiente')     
    return render(request, "turnos/listar_turnos_pendientes.html", {'pendientes': pendientes})

from datetime import date
def listar_turnos_aceptados(request):
    aceptados_TODOS=Turno.objects.filter(estado='Aceptado').order_by('dia')
    hoy = date.today()
    aceptados_hoy = aceptados_TODOS.filter(dia=hoy).order_by('franja_horaria')
    aceptados_futuros = aceptados_TODOS.filter(dia__gt=hoy).order_by('franja_horaria')
    aceptados_pasados = aceptados_TODOS.filter(dia__lt=hoy).order_by('franja_horaria')

    return render(request, "turnos/listar_turnos_aceptados.html", {'aceptados_hoy': aceptados_hoy, 'aceptados_futuros': aceptados_futuros, "aceptados_pasados":aceptados_pasados})

def listar_turnos_cancelados(request):
    cancelados=Turno.objects.filter(estado='Cancelado')     
    return render(request, "turnos/listar_turnos_cancelados.html", {'cancelados': cancelados})

def listar_turnos_rechazados(request):
    rechazados=Turno.objects.filter(estado='Rechazado')     
    return render(request, "turnos/listar_turnos_rechazados.html", {'rechazados': rechazados})


from .forms import AsignarTurnoForm
def asignar_turnos_pendientes(request):
    turnos_pendientes = Turno.objects.filter(estado='Pendiente').order_by('dia').order_by('franja_horaria')

    if request.method == 'POST':
        form = AsignarTurnoForm(request.POST)
        if form.is_valid():
            turno_id = form.data.get('turno_id')  # Obtén el ID del turno seleccionado
            nuevo_estado = form.cleaned_data['estado']  # Obtén el nuevo estado del formulario
            turno = Turno.objects.get(pk=turno_id)
            turno.estado = nuevo_estado
            turno.save()
    else:
        
        form = AsignarTurnoForm(initial={'estado': 'Pendiente'})  # Establecer valor inicial

    return render(request, "turnos/asignar_turnos_pendientes.html", {'turnos_pendientes': turnos_pendientes, 'form':form })


def asignar_estado_turno(request, id):
    turno = get_object_or_404(Turno, id=id)
    if request.method == 'POST':
        estado = request.POST.get('estado')
        # Aquí puedes realizar las acciones correspondientes según el estado
        if estado == 'Aceptar':
            # Lógica para aceptar el turno
            turno.estado="Aceptado"
            turno.save()
        elif estado == 'Rechazar':
            turno.estado="Rechazado"
            turno.save()
            # Lógica para rechazar el turno
    
    return redirect('Asignar_turnos_pendientes')  # Redirig


@login_required
def ver_mis_turnos(request):
    perros_del_cliente = Perros.objects.filter(dueno=request.user) #Primero guardo todos los perros del cliente
    perros_y_turnos = {}  

    #las guardo en un diccionario
    #diccionario de querysets.
    for perro_actual in perros_del_cliente:
        perros_y_turnos[perro_actual]=Turno.objects.filter(perro=perro_actual)



    print('cantidad de perros %s' %(perros_del_cliente.count()))
    print(request.user)
    print(request.user.username)
    print(request.user.first_name)
    print(request.user.email)
    print('')
    print(perros_y_turnos)

    return render(request, r'turnos\ver_mis_turnos.html', {'perros_y_turnos': perros_y_turnos})


def cancelar_turno(request,id):
    turno=get_object_or_404(Turno,id=id)
    if turno:
        turno.estado="Cancelado"
        turno.save()
        print("turno cancelado!")
        print(turno.estado)
    return redirect('Ver_mis_turnos')  # Si logro solicitar el turno lo redirije a la seccion "ver mis turnos"
