from django.contrib import admin

# Register your models here.
from django.contrib import admin
from turnos.models import Turno


class TurnoAdmin(admin.ModelAdmin):
    list_filter = ('dia','dia')
    
admin.site.register(Turno, TurnoAdmin)