from django import forms
from .models import Turno
from django.forms.widgets import DateInput
from datetime import date, timedelta
from django.db.models import F
from perro.models import Perros;

#es por aca, chatGPT nos dio lo mismo (para el model en particular que tenemos de Turno) y casi igual a lo que tienen los pibes.

from django.utils.translation import gettext as _
from django.utils.translation import *

class SolicitarTurnoForm(forms.ModelForm):
    # fecha=DateInput(type=date, min=str(date.today()))   PROBAR
    dia= forms.DateField(label='Fecha', widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}), initial=date.today() + timedelta(days=1))
    medico = forms.ChoiceField(label= 'Motivo', choices=Turno.OPCIONES_MEDICAS)
    perro = forms.ModelChoiceField(queryset=Perros.objects.none())  # Crea queryset vacio
    franja_horaria=forms.ChoiceField(label= 'Franja Horaria', choices=Turno.HORARIOS)
    descripcion= forms.CharField(label='Descripción', required=False)

    class Meta:
        model = Turno
        fields = ['medico', 'perro', 'descripcion', 'dia', 'franja_horaria', ]        
        #probar esto de widgets despues
        # widgets = {
        #     'fecha': DateInput(attrs={'type': 'date','min': str(date.today())})
        # }

    def __init__(self, *args, **kwargs):
        usuario = kwargs.pop('usuario', None)  # Obtener el usuario del argumento 'usuario'
        super().__init__(*args, **kwargs)

        if usuario:
            self.fields['perro'].queryset = Perros.objects.filter(dueno__email=usuario.email)
        
    def clean_dia(self):
        dia = self.cleaned_data.get('dia')
        if dia and dia <= date.today():
            raise forms.ValidationError("Selecciona una fecha futura.")
        return dia


class AsignarTurnoForm(forms.ModelForm):
    class Meta:
        model = Turno
        fields = ['estado']
